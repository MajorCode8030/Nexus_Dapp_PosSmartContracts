// SPDX-License-Identifier: MIT
pragma solidity 0.8.28;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import {ERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import {ERC20Votes} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Votes.sol";
import {Ownable2Step, Ownable} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {Nonces} from "@openzeppelin/contracts/utils/Nonces.sol";

contract NexusToken is ERC20, ERC20Burnable, ERC20Permit, ERC20Votes, Ownable2Step {
    uint256 public constant MAX_SUPPLY = 100_000_000 * 1e18;

    error NexusToken__ExceedsMaxSupply();

    constructor(address initialOwner)
        ERC20("Nexus Token", "NXS")
        ERC20Permit("Nexus Token")
        Ownable(initialOwner)
    {
        _mint(initialOwner, 10_000_000 * 1e18);
    }

    function mint(address to, uint256 amount) external onlyOwner {
        if (totalSupply() + amount > MAX_SUPPLY) revert NexusToken__ExceedsMaxSupply();
        _mint(to, amount);
    }

    function _update(address from, address to, uint256 value) internal override(ERC20, ERC20Votes) {
        super._update(from, to, value);
    }

    function nonces(address owner) public view override(ERC20Permit, Nonces) returns (uint256) {
        return super.nonces(owner);
    }
}
