// SPDX-License-Identifier: MIT
// @custom:security-contact security@contratoteste.com
pragma solidity 0.8.28;

import {IERC721} from "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import {IERC721Receiver} from "@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol";
import {Ownable2Step, Ownable} from "@openzeppelin/contracts/access/Ownable2Step.sol";
import {ReentrancyGuardTransient} from "@openzeppelin/contracts/utils/ReentrancyGuardTransient.sol";
import {Pausable} from "@openzeppelin/contracts/utils/Pausable.sol";

contract ContratoTesteStaking is IERC721Receiver, Ownable2Step, ReentrancyGuardTransient, Pausable {
    error ContratoTesteStaking__NotTokenOwner();
    error ContratoTesteStaking__TokenNotStaked();
    error ContratoTesteStaking__AlreadyStaked();
    error ContratoTesteStaking__ZeroAddress();
    error ContratoTesteStaking__TransferFailed();

    struct StakeInfo {
        address owner;
        uint256 stakedAt;
    }

    IERC721 public immutable nftContract;
    uint256 public constant REWARD_RATE = 1e15;

    mapping(uint256 => StakeInfo) private _stakes;
    mapping(address => uint256[]) private _stakedTokens;
    mapping(address => uint256) public pendingRewards;

    event Staked(address indexed user, uint256 indexed tokenId);
    event Unstaked(address indexed user, uint256 indexed tokenId, uint256 reward);
    event RewardClaimed(address indexed user, uint256 amount);

    constructor(address nftAddress, address initialOwner) Ownable(initialOwner) {
        if (nftAddress == address(0)) revert ContratoTesteStaking__ZeroAddress();
        nftContract = IERC721(nftAddress);
    }

    function stake(uint256 tokenId) external nonReentrant whenNotPaused {
        if (nftContract.ownerOf(tokenId) != msg.sender) revert ContratoTesteStaking__NotTokenOwner();
        if (_stakes[tokenId].owner != address(0)) revert ContratoTesteStaking__AlreadyStaked();
        nftContract.safeTransferFrom(msg.sender, address(this), tokenId);
        _stakes[tokenId] = StakeInfo({ owner: msg.sender, stakedAt: block.timestamp });
        _stakedTokens[msg.sender].push(tokenId);
        emit Staked(msg.sender, tokenId);
    }

    function unstake(uint256 tokenId) external nonReentrant whenNotPaused {
        StakeInfo memory info = _stakes[tokenId];
        if (info.owner != msg.sender) revert ContratoTesteStaking__NotTokenOwner();
        uint256 reward = _calculateReward(tokenId);
        delete _stakes[tokenId];
        _removeFromStakedTokens(msg.sender, tokenId);
        pendingRewards[msg.sender] += reward;
        nftContract.safeTransferFrom(address(this), msg.sender, tokenId);
        emit Unstaked(msg.sender, tokenId, reward);
    }

    function claimRewards() external nonReentrant {
        uint256 amount = pendingRewards[msg.sender];
        if (amount == 0) return;
        pendingRewards[msg.sender] = 0;
        (bool ok,) = msg.sender.call{value: amount}("");
        if (!ok) revert ContratoTesteStaking__TransferFailed();
        emit RewardClaimed(msg.sender, amount);
    }

    function getStakeInfo(uint256 tokenId) external view returns (address owner, uint256 stakedAt, uint256 currentReward) {
        StakeInfo memory info = _stakes[tokenId];
        owner = info.owner;
        stakedAt = info.stakedAt;
        currentReward = info.owner != address(0) ? _calculateReward(tokenId) : 0;
    }

    function getStakedTokens(address user) external view returns (uint256[] memory) {
        return _stakedTokens[user];
    }

    function _calculateReward(uint256 tokenId) internal view returns (uint256) {
        return (block.timestamp - _stakes[tokenId].stakedAt) * REWARD_RATE;
    }

    function _removeFromStakedTokens(address user, uint256 tokenId) internal {
        uint256[] storage tokens = _stakedTokens[user];
        for (uint256 i; i < tokens.length; ++i) {
            if (tokens[i] == tokenId) {
                tokens[i] = tokens[tokens.length - 1];
                tokens.pop();
                break;
            }
        }
    }

    function onERC721Received(address, address, uint256, bytes calldata) external pure override returns (bytes4) {
        return IERC721Receiver.onERC721Received.selector;
    }

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    receive() external payable {}
}
