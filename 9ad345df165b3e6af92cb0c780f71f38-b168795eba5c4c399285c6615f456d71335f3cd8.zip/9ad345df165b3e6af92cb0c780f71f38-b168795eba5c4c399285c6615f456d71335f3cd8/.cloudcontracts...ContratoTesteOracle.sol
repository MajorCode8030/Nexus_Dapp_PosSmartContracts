// SPDX-License-Identifier: MIT
// @custom:security-contact security@contratoteste.com
pragma solidity 0.8.28;

import {AggregatorV3Interface} from "@chainlink/contracts/src/v0.8/shared/interfaces/AggregatorV3Interface.sol";
import {Ownable2Step, Ownable} from "@openzeppelin/contracts/access/Ownable2Step.sol";

contract ContratoTesteOracle is Ownable2Step {
    error ContratoTesteOracle__InvalidPrice();
    error ContratoTesteOracle__StalePrice();
    error ContratoTesteOracle__ZeroAddress();

    AggregatorV3Interface public immutable priceFeed;
    uint256 public constant STALENESS_THRESHOLD = 3600;

    event PriceRead(int256 price, uint256 timestamp);

    constructor(address feedAddress, address initialOwner) Ownable(initialOwner) {
        if (feedAddress == address(0)) revert ContratoTesteOracle__ZeroAddress();
        priceFeed = AggregatorV3Interface(feedAddress);
    }

    function getLatestPrice() external view returns (int256 price, uint256 updatedAt) {
        (, price,, updatedAt,) = priceFeed.latestRoundData();
        if (price <= 0) revert ContratoTesteOracle__InvalidPrice();
        if (block.timestamp - updatedAt > STALENESS_THRESHOLD) revert ContratoTesteOracle__StalePrice();
    }

    function getDecimals() external view returns (uint8) {
        return priceFeed.decimals();
    }
}
