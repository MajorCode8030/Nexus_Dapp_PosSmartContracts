import React, { useState } from 'react';
import { ethers } from 'ethers';

const OwnershipPanel = ({ contract, account, signer, showToast }) => {
  const [newOwner, setNewOwner] = useState('');
  const [loading, setLoading] = useState(false);

  const handleTransferOwnership = async () => {
    if (!newOwner) {
      showToast('Please enter new owner address', 'error');
      return;
    }

    try {
      setLoading(true);
      const tx = await contract.transferOwnership(newOwner);
      showToast('Ownership transfer initiated...', 'info');
      await tx.wait();
      showToast('Ownership transfer pending! New owner must accept.', 'success');
      setNewOwner('');
    } catch (error) {
      console.error('Transfer ownership error:', error);
      if (error.code === 4001) {
        showToast('User rejected transaction', 'error');
      } else {
        showToast('Failed to transfer ownership', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAcceptOwnership = async () => {
    try {
      setLoading(true);
      const tx = await contract.acceptOwnership();
      showToast('Accepting ownership...', 'info');
      await tx.wait();
      showToast('Ownership accepted successfully!', 'success');
    } catch (error) {
      console.error('Accept ownership error:', error);
      if (error.code === 4001) {
        showToast('User rejected transaction', 'error');
      } else {
        showToast('Failed to accept ownership', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleRenounceOwnership = async () => {
    if (!window.confirm('WARNING: This will permanently renounce ownership. Are you sure?')) {
      return;
    }

    try {
      setLoading(true);
      const tx = await contract.renounceOwnership();
      showToast('Renouncing ownership...', 'info');
      await tx.wait();
      showToast('Ownership renounced permanently!', 'success');
    } catch (error) {
      console.error('Renounce ownership error:', error);
      if (error.code === 4001) {
        showToast('User rejected transaction', 'error');
      } else {
        showToast('Failed to renounce ownership', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const fillCurrentAccount = () => {
    if (!account) {
      showToast('Please connect wallet first', 'error');
      return;
    }
    setNewOwner(account);
  };

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-cyber font-bold mb-2 bg-gradient-to-r from-cyber-pink to-cyber-green bg-clip-text text-transparent">
          OWNERSHIP MANAGEMENT
        </h2>
        <p className="text-cyber-gray">Transfer, accept, or renounce contract ownership</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Transfer Ownership */}
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-pink/30">
          <h3 className="text-2xl font-cyber text-cyber-pink mb-6">TRANSFER OWNERSHIP</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-cyber-gray mb-2">New Owner Address</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newOwner}
                  onChange={(e) => setNewOwner(e.target.value)}
                  placeholder="0x..."
                  className="flex-1 bg-cyber-dark border border-cyber-pink/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-pink"
                />
                <button
                  onClick={fillCurrentAccount}
                  className="px-4 bg-cyber-pink/20 hover:bg-cyber-pink/30 text-cyber-pink rounded-lg text-sm"
                >
                  USE MY ADDRESS
                </button>
              </div>
            </div>
            <button
              onClick={handleTransferOwnership}
              disabled={loading || !account}
              className="w-full py-3 bg-gradient-to-r from-cyber-pink to-purple-600 hover:from-purple-600 hover:to-cyber-pink text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  TRANSFERRING...
                </div>
              ) : (
                'TRANSFER OWNERSHIP'
              )}
            </button>
            <p className="text-xs text-cyber-gray text-center">
              New owner must call "Accept Ownership" to complete transfer
            </p>
          </div>
        </div>

        {/* Accept Ownership */}
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-green/30">
          <h3 className="text-2xl font-cyber text-cyber-green mb-6">ACCEPT OWNERSHIP</h3>
          <div className="space-y-4">
            <div className="p-4 bg-cyber-dark/50 rounded-lg">
              <div className="text-sm text-cyber-gray mb-2">Status</div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-cyber-green rounded-full mr-2 animate-pulse-neon"></div>
                <span className="text-white">Pending ownership transfer can be accepted here</span>
              </div>
            </div>
            <button
              onClick={handleAcceptOwnership}
              disabled={loading || !account}
              className="w-full py-3 bg-gradient-to-r from-cyber-green to-green-600 hover:from-green-600 hover:to-cyber-green text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  ACCEPTING...
                </div>
              ) : (
                'ACCEPT OWNERSHIP'
              )}
            </button>
            <p className="text-xs text-cyber-gray text-center">
              Only the pending owner can call this function
            </p>
          </div>
        </div>

        {/* Renounce Ownership */}
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-red-700/30 col-span-1 lg:col-span-2">
          <h3 className="text-2xl font-cyber text-red-400 mb-6">RENOUNCE OWNERSHIP</h3>
          <div className="max-w-2xl mx-auto">
            <div className="p-6 bg-red-900/10 border border-red-700/30 rounded-lg mb-6">
              <div className="flex items-start mb-4">
                <div className="text-2xl mr-3">⚠️</div>
                <div>
                  <h4 className="text-red-300 font-cyber text-lg mb-2">WARNING: IRREVERSIBLE ACTION</h4>
                  <p className="text-red-200/70 text-sm">
                    Renouncing ownership will permanently remove all owner privileges from the current owner.
                    This action cannot be undone. The contract will become ownerless, and no one will be able to:
                  </p>
                  <ul className="list-disc list-inside text-red-200/70 text-sm mt-3 space-y-1">
                    <li>Mint new NFTs</li>
                    <li>Transfer ownership</li>
                    <li>Perform any owner-only functions</li>
                  </ul>
                </div>
              </div>
            </div>
            <button
              onClick={handleRenounceOwnership}
              disabled={loading || !account}
              className="w-full py-4 bg-gradient-to-r from-red-700 to-red-900 hover:from-red-800 hover:to-red-700 text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  RENOUNCING...
                </div>
              ) : (
                'PERMANENTLY RENOUNCE OWNERSHIP'
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Ownership Info */}
      <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-blue/20">
        <h3 className="text-xl font-cyber text-cyber-blue mb-4">OWNERSHIP FLOW</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-cyber-blue/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-cyber-blue text-2xl">1</span>
            </div>
            <div className="font-cyber text-cyber-blue mb-2">CURRENT OWNER</div>
            <p className="text-sm text-cyber-gray">Can transfer ownership to new address</p>
          </div>
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-cyber-purple/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-cyber-purple text-2xl">→</span>
            </div>
            <div className="font-cyber text-cyber-purple mb-2">TRANSFER</div>
            <p className="text-sm text-cyber-gray">Initiate transfer, creates pending owner</p>
          </div>
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-cyber-green/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-cyber-green text-2xl">2</span>
            </div>
            <div className="font-cyber text-cyber-green mb-2">PENDING OWNER</div>
            <p className="text-sm text-cyber-gray">Must accept to become new owner</p>
          </div>
          <div className="text-center p-4">
            <div className="w-12 h-12 bg-red-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-red-400 text-2xl">✗</span>
            </div>
            <div className="font-cyber text-red-400 mb-2">RENOUNCE</div>
            <p className="text-sm text-cyber-gray">Permanent, irreversible action</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OwnershipPanel;