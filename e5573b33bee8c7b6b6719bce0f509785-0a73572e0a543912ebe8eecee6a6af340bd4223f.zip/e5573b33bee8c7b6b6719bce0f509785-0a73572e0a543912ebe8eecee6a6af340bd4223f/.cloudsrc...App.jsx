import React, { useState, useEffect, useRef } from 'react';
import { ethers } from 'ethers';
import Navbar from './components/Navbar.jsx';
import Dashboard from './components/Dashboard.jsx';
import NFTManagement from './components/NFTManagement.jsx';
import OwnershipPanel from './components/OwnershipPanel.jsx';

const CONTRACT_ADDRESS = '0xe35c4Fa7DDeB3E85C7029F075ECB0343021F986D';
const TARGET_CHAIN_ID = 11155111; // Sepolia

const CONTRACT_ABI = [
  {"inputs":[],"name":"acceptOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[],"name":"renounceOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"to","type":"address"},{"internalType":"string","name":"uri","type":"string"}],"name":"safeMint","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"},{"internalType":"bytes","name":"data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"operator","type":"address"},{"internalType":"bool","name":"approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"from","type":"address"},{"internalType":"address","name":"to","type":"address"},{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},
  {"inputs":[{"internalType":"address","name":"owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"address","name":"operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},
  {"inputs":[],"name":"MAX_SUPPLY","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},
  {"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},
  {"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},
  {"inputs":[],"name":"pendingOwner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"bytes4","name":"interfaceId","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},
  {"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"address","name":"owner","type":"address"},{"internalType":"uint256","name":"index","type":"uint256"}],"name":"tokenOfOwnerByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},
  {"inputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},
  {"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"}
];

function App() {
  const [account, setAccount] = useState(null);
  const [chainId, setChainId] = useState(null);
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [contract, setContract] = useState(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ show: false, message: '', type: 'info' });
  const [route, setRoute] = useState(window.location.hash || '#/dashboard');
  const rawProviderRef = useRef(null);

  const config = window.__QUICK_DAPP_CONFIG__ || {};

  // Initialize wallet connection
  const connectWallet = async () => {
    try {
      setLoading(true);
      const rawProvider = window.__qdapp_getProvider
        ? await window.__qdapp_getProvider()
        : window.ethereum;
      
      if (!rawProvider) {
        alert('Please install a Web3 wallet (e.g. MetaMask).');
        return;
      }

      rawProviderRef.current = rawProvider;
      const provider = new ethers.BrowserProvider(rawProvider);
      const network = await provider.getNetwork();
      const currentChainId = Number(network.chainId);
      
      setProvider(provider);
      setChainId(currentChainId);

      const signer = await provider.getSigner();
      const address = await signer.getAddress();
      setSigner(signer);
      setAccount(address);

      const contract = new ethers.Contract(CONTRACT_ADDRESS, CONTRACT_ABI, signer);
      setContract(contract);

      // Save wallet preference
      try {
        if (rawProvider.info?.rdns) {
          localStorage.setItem('__qdapp_wallet_rdns', rawProvider.info.rdns);
        }
      } catch (e) {}

      showToast('Wallet connected successfully', 'success');
    } catch (error) {
      console.error('Connection error:', error);
      if (error.code === 4001) {
        showToast('User rejected connection', 'error');
      } else {
        showToast('Failed to connect wallet', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const disconnectWallet = () => {
    setAccount(null);
    setProvider(null);
    setSigner(null);
    setContract(null);
    rawProviderRef.current = null;
    try {
      localStorage.removeItem('__qdapp_wallet_rdns');
    } catch (e) {}
    showToast('Wallet disconnected', 'info');
  };

  const switchNetwork = async () => {
    const rp = rawProviderRef.current;
    if (!rp) return;
    
    try {
      await rp.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: '0x' + TARGET_CHAIN_ID.toString(16) }],
      });
      showToast('Network switched successfully', 'success');
    } catch (switchError) {
      if (switchError.code === 4902) {
        try {
          await rp.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: '0xaa36a7',
              chainName: 'Sepolia',
              nativeCurrency: { name: 'Sepolia ETH', symbol: 'ETH', decimals: 18 },
              rpcUrls: ['https://rpc.sepolia.org'],
              blockExplorerUrls: ['https://sepolia.etherscan.io']
            }]
          });
        } catch (addError) {
          showToast('Failed to add network', 'error');
        }
      } else {
        showToast('Failed to switch network', 'error');
      }
    }
  };

  const showToast = (message, type) => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'info' }), 3000);
  };

  // Event listeners
  useEffect(() => {
    const rp = rawProviderRef.current;
    if (!rp?.on) return;

    const handleAccountsChanged = (accounts) => {
      if (accounts.length === 0) disconnectWallet();
      else setAccount(accounts[0]);
    };

    const handleChainChanged = (chainIdHex) => {
      setChainId(parseInt(chainIdHex, 16));
    };

    rp.on('accountsChanged', handleAccountsChanged);
    rp.on('chainChanged', handleChainChanged);

    return () => {
      rp.removeListener('accountsChanged', handleAccountsChanged);
      rp.removeListener('chainChanged', handleChainChanged);
    };
  }, [account]);

  // Hash router
  useEffect(() => {
    const onHashChange = () => setRoute(window.location.hash || '#/dashboard');
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = (path) => {
    window.location.hash = path;
  };

  const isWrongNetwork = account && chainId !== null && chainId !== TARGET_CHAIN_ID;

  return (
    <div className="min-h-screen bg-cyber-dark text-white font-tech scan-line">
      {/* Background grid */}
      <div className="fixed inset-0 grid-pattern opacity-10 pointer-events-none"></div>
      
      <Navbar
        account={account}
        chainId={chainId}
        isWrongNetwork={isWrongNetwork}
        onConnect={connectWallet}
        onDisconnect={disconnectWallet}
        onSwitchNetwork={switchNetwork}
        loading={loading}
        config={config}
        navigate={navigate}
        route={route}
      />

      <main className="container mx-auto px-4 pt-24 pb-12">
        {route === '#/dashboard' && (
          <Dashboard
            contract={contract}
            account={account}
            provider={provider}
            showToast={showToast}
          />
        )}
        
        {route === '#/nft' && (
          <NFTManagement
            contract={contract}
            account={account}
            signer={signer}
            showToast={showToast}
          />
        )}
        
        {route === '#/ownership' && (
          <OwnershipPanel
            contract={contract}
            account={account}
            signer={signer}
            showToast={showToast}
          />
        )}
      </main>

      {/* Toast notification */}
      {toast.show && (
        <div className={`fixed bottom-4 right-4 px-6 py-3 rounded-lg border ${
          toast.type === 'success' ? 'bg-green-900/30 border-cyber-green text-cyber-green' :
          toast.type === 'error' ? 'bg-red-900/30 border-red-500 text-red-300' :
          'bg-cyber-gray border-cyber-blue text-cyber-blue'
        } z-50 animate-pulse-neon`}>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${
              toast.type === 'success' ? 'bg-cyber-green' :
              toast.type === 'error' ? 'bg-red-500' : 'bg-cyber-blue'
            }`}></div>
            <span className="font-cyber text-sm">{toast.message}</span>
          </div>
        </div>
      )}

      {/* Cyberpunk footer */}
      <footer className="border-t border-cyber-gray/50 mt-12 py-6">
        <div className="container mx-auto px-4 text-center text-cyber-gray">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <span className="text-cyber-blue font-cyber">SYSTEM STATUS:</span>
              <span className="ml-2 text-cyber-green">ONLINE</span>
            </div>
            <div className="text-sm">
              <span className="text-cyber-purple">CHAIN_ID:</span>
              <span className="ml-2">{chainId || '--'}</span>
              <span className="mx-4">|</span>
              <span className="text-cyber-pink">CONTRACT:</span>
              <span className="ml-2 font-mono text-xs">{CONTRACT_ADDRESS.slice(0, 10)}...{CONTRACT_ADDRESS.slice(-8)}</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;