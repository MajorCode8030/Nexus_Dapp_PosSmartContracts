import React from 'react';
import { ethers } from 'ethers';

const Navbar = ({
  account,
  chainId,
  isWrongNetwork,
  onConnect,
  onDisconnect,
  onSwitchNetwork,
  loading,
  config,
  navigate,
  route
}) => {
  const truncateAddress = (addr) => {
    if (!addr) return '';
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-cyber-dark/90 backdrop-blur-md border-b border-cyber-blue/30">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo and Title */}
          <div className="flex items-center space-x-4">
            {config.logo && (
              <img 
                src={config.logo} 
                alt="Logo"
                className="w-10 h-10 rounded-full neon-border"
              />
            )}
            <div>
              <h1 className="text-2xl font-cyber font-bold bg-gradient-to-r from-cyber-blue to-cyber-purple bg-clip-text text-transparent">
                {config.title || 'CYBERPUNK NFT HUB'}
              </h1>
              {config.details && (
                <p className="text-xs text-cyber-gray mt-1">{config.details}</p>
              )}
            </div>
          </div>

          {/* Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            <button
              onClick={() => navigate('#/dashboard')}
              className={`px-4 py-2 rounded-lg transition-all ${
                route === '#/dashboard'
                  ? 'bg-cyber-blue/20 text-cyber-blue border border-cyber-blue'
                  : 'text-gray-400 hover:text-cyber-blue hover:bg-cyber-blue/10'
              }`}
            >
              <span className="font-cyber">DASHBOARD</span>
            </button>
            <button
              onClick={() => navigate('#/nft')}
              className={`px-4 py-2 rounded-lg transition-all ${
                route === '#/nft'
                  ? 'bg-cyber-purple/20 text-cyber-purple border border-cyber-purple'
                  : 'text-gray-400 hover:text-cyber-purple hover:bg-cyber-purple/10'
              }`}
            >
              <span className="font-cyber">NFT MANAGEMENT</span>
            </button>
            <button
              onClick={() => navigate('#/ownership')}
              className={`px-4 py-2 rounded-lg transition-all ${
                route === '#/ownership'
                  ? 'bg-cyber-pink/20 text-cyber-pink border border-cyber-pink'
                  : 'text-gray-400 hover:text-cyber-pink hover:bg-cyber-pink/10'
              }`}
            >
              <span className="font-cyber">OWNERSHIP</span>
            </button>
          </div>

          {/* Wallet Connection */}
          <div className="flex items-center space-x-3">
            {isWrongNetwork && (
              <button
                onClick={onSwitchNetwork}
                className="px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg text-sm font-cyber animate-pulse"
              >
                SWITCH TO SEPOLIA
              </button>
            )}
            
            {account ? (
              <div className="flex items-center space-x-3">
                <div className="px-4 py-2 bg-cyber-gray rounded-lg border border-cyber-blue/30">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-cyber-green rounded-full mr-2 animate-pulse-neon"></div>
                    <span className="font-mono text-sm">{truncateAddress(account)}</span>
                  </div>
                  <div className="text-xs text-cyber-gray mt-1">
                    CHAIN: {chainId || '--'}
                  </div>
                </div>
                <button
                  onClick={onDisconnect}
                  className="px-4 py-2 bg-red-900/30 hover:bg-red-900/50 text-red-300 rounded-lg border border-red-700 text-sm font-cyber"
                >
                  DISCONNECT
                </button>
              </div>
            ) : (
              <button
                onClick={onConnect}
                disabled={loading}
                className="px-6 py-3 bg-gradient-to-r from-cyber-blue to-cyber-purple hover:from-cyber-purple hover:to-cyber-blue text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
              >
                {loading ? (
                  <div className="flex items-center">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    CONNECTING...
                  </div>
                ) : (
                  'CONNECT WALLET'
                )}
              </button>
            )}
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="flex md:hidden justify-center mt-4 space-x-4">
          <button
            onClick={() => navigate('#/dashboard')}
            className={`px-3 py-1 text-sm rounded ${
              route === '#/dashboard' ? 'bg-cyber-blue/20 text-cyber-blue' : 'text-gray-400'
            }`}
          >
            DASH
          </button>
          <button
            onClick={() => navigate('#/nft')}
            className={`px-3 py-1 text-sm rounded ${
              route === '#/nft' ? 'bg-cyber-purple/20 text-cyber-purple' : 'text-gray-400'
            }`}
          >
            NFT
          </button>
          <button
            onClick={() => navigate('#/ownership')}
            className={`px-3 py-1 text-sm rounded ${
              route === '#/ownership' ? 'bg-cyber-pink/20 text-cyber-pink' : 'text-gray-400'
            }`}
          >
            OWNER
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;