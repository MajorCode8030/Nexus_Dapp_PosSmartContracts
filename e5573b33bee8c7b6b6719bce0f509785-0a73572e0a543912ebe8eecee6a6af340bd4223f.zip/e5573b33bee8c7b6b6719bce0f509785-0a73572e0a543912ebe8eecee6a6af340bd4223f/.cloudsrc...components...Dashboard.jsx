import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';

const Dashboard = ({ contract, account, provider, showToast }) => {
  const [contractInfo, setContractInfo] = useState({
    name: '',
    symbol: '',
    totalSupply: '0',
    maxSupply: '0',
    owner: '',
    pendingOwner: ''
  });
  const [userBalance, setUserBalance] = useState('0');
  const [loading, setLoading] = useState(true);
  const [userNFTs, setUserNFTs] = useState([]);

  useEffect(() => {
    if (contract && provider) {
      fetchContractData();
    }
  }, [contract, account]);

  const fetchContractData = async () => {
    try {
      setLoading(true);
      
      // Fetch contract info
      const name = await contract.name();
      const symbol = await contract.symbol();
      const totalSupply = await contract.totalSupply();
      const maxSupply = await contract.MAX_SUPPLY();
      const owner = await contract.owner();
      const pendingOwner = await contract.pendingOwner();

      setContractInfo({
        name,
        symbol,
        totalSupply: totalSupply.toString(),
        maxSupply: maxSupply.toString(),
        owner,
        pendingOwner
      });

      // Fetch user balance if connected
      if (account) {
        const balance = await contract.balanceOf(account);
        setUserBalance(balance.toString());

        // Fetch user's NFTs
        const nfts = [];
        const balanceNum = parseInt(balance.toString());
        for (let i = 0; i < balanceNum; i++) {
          try {
            const tokenId = await contract.tokenOfOwnerByIndex(account, i);
            const tokenURI = await contract.tokenURI(tokenId);
            nfts.push({
              id: tokenId.toString(),
              uri: tokenURI
            });
          } catch (err) {
            console.error('Error fetching NFT:', err);
          }
        }
        setUserNFTs(nfts);
      }
    } catch (error) {
      console.error('Error fetching contract data:', error);
      showToast('Failed to load contract data', 'error');
    } finally {
      setLoading(false);
    }
  };

  const refreshData = () => {
    fetchContractData();
    showToast('Data refreshed', 'info');
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-cyber-blue border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-cyber-blue font-cyber">LOADING CONTRACT DATA...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-4xl font-cyber font-bold mb-2 bg-gradient-to-r from-cyber-blue via-cyber-purple to-cyber-pink bg-clip-text text-transparent">
          {contractInfo.name} DASHBOARD
        </h2>
        <p className="text-cyber-gray">Real-time blockchain data visualization</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-cyber-gray/30 rounded-xl p-6 border border-cyber-blue/30 hover:border-cyber-blue transition-all">
          <div className="text-cyber-blue font-cyber text-sm mb-2">TOTAL SUPPLY</div>
          <div className="text-3xl font-bold text-white">{contractInfo.totalSupply}</div>
          <div className="text-sm text-cyber-gray mt-2">of {contractInfo.maxSupply} MAX</div>
        </div>

        <div className="bg-cyber-gray/30 rounded-xl p-6 border border-cyber-purple/30 hover:border-cyber-purple transition-all">
          <div className="text-cyber-purple font-cyber text-sm mb-2">SYMBOL</div>
          <div className="text-3xl font-bold text-white">{contractInfo.symbol}</div>
          <div className="text-sm text-cyber-gray mt-2">ERC-721 Token</div>
        </div>

        <div className="bg-cyber-gray/30 rounded-xl p-6 border border-cyber-pink/30 hover:border-cyber-pink transition-all">
          <div className="text-cyber-pink font-cyber text-sm mb-2">YOUR BALANCE</div>
          <div className="text-3xl font-bold text-white">{userBalance}</div>
          <div className="text-sm text-cyber-gray mt-2">
            {account ? truncateAddress(account) : 'Not connected'}
          </div>
        </div>

        <div className="bg-cyber-gray/30 rounded-xl p-6 border border-cyber-green/30 hover:border-cyber-green transition-all">
          <div className="text-cyber-green font-cyber text-sm mb-2">OWNER</div>
          <div className="text-lg font-mono text-white truncate">{truncateAddress(contractInfo.owner)}</div>
          {contractInfo.pendingOwner !== ethers.ZeroAddress && (
            <div className="text-xs text-yellow-400 mt-2">Pending transfer</div>
          )}
        </div>
      </div>

      {/* Your NFTs */}
      {account && (
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-blue/20">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-2xl font-cyber text-cyber-blue">YOUR NFT COLLECTION</h3>
            <button
              onClick={refreshData}
              className="px-4 py-2 bg-cyber-blue/20 hover:bg-cyber-blue/30 text-cyber-blue rounded-lg text-sm font-cyber transition-all"
            >
              REFRESH
            </button>
          </div>

          {userNFTs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {userNFTs.map((nft, index) => (
                <div
                  key={index}
                  className="bg-cyber-dark rounded-lg p-4 border border-cyber-purple/30 hover:border-cyber-purple transition-all"
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-cyber text-cyber-purple">ID: {nft.id}</span>
                    <div className="w-2 h-2 bg-cyber-green rounded-full animate-pulse-neon"></div>
                  </div>
                  <div className="h-40 bg-gradient-to-br from-cyber-blue/10 to-cyber-purple/10 rounded-lg mb-3 flex items-center justify-center">
                    <div className="text-center">
                      <div className="text-4xl mb-2">🔗</div>
                      <div className="text-xs text-cyber-gray truncate px-2">{nft.uri}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(nft.uri);
                      showToast('URI copied to clipboard', 'success');
                    }}
                    className="w-full py-2 bg-cyber-purple/20 hover:bg-cyber-purple/30 text-cyber-purple rounded text-sm transition-all"
                  >
                    COPY URI
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <div className="text-6xl mb-4">🔄</div>
              <p className="text-cyber-gray">No NFTs found in your wallet</p>
              <p className="text-sm text-cyber-gray mt-2">Mint some NFTs to get started</p>
            </div>
          )}
        </div>
      )}

      {/* Contract Info */}
      <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-green/20">
        <h3 className="text-2xl font-cyber text-cyber-green mb-4">CONTRACT INFORMATION</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-cyber-gray">Contract Address:</span>
              <span className="font-mono text-sm">{truncateAddress(contract.target)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyber-gray">Owner:</span>
              <span className="font-mono text-sm">{truncateAddress(contractInfo.owner)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyber-gray">Pending Owner:</span>
              <span className="font-mono text-sm">
                {contractInfo.pendingOwner !== ethers.ZeroAddress 
                  ? truncateAddress(contractInfo.pendingOwner)
                  : 'None'}
              </span>
            </div>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-cyber-gray">Total Supply:</span>
              <span className="font-mono">{contractInfo.totalSupply}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyber-gray">Max Supply:</span>
              <span className="font-mono">{contractInfo.maxSupply}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-cyber-gray">Your Balance:</span>
              <span className="font-mono">{userBalance}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const truncateAddress = (addr) => {
  if (!addr) return '--';
  return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
};

export default Dashboard;