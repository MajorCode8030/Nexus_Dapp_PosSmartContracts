import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';

const NFTManagement = ({ contract, account, signer, showToast }) => {
  const [mintTo, setMintTo] = useState('');
  const [mintURI, setMintURI] = useState('');
  const [transferFrom, setTransferFrom] = useState('');
  const [transferTo, setTransferTo] = useState('');
  const [transferTokenId, setTransferTokenId] = useState('');
  const [approveTo, setApproveTo] = useState('');
  const [approveTokenId, setApproveTokenId] = useState('');
  const [setApprovalForAllOperator, setSetApprovalForAllOperator] = useState('');
  const [setApprovalForAllApproved, setSetApprovalForAllApproved] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleMint = async () => {
    if (!mintTo || !mintURI) {
      showToast('Please fill all fields', 'error');
      return;
    }

    try {
      setLoading(true);
      const tx = await contract.safeMint(mintTo, mintURI);
      showToast('Transaction sent...', 'info');
      await tx.wait();
      showToast('NFT minted successfully!', 'success');
      setMintTo('');
      setMintURI('');
    } catch (error) {
      console.error('Mint error:', error);
      if (error.code === 4001) {
        showToast('User rejected transaction', 'error');
      } else {
        showToast('Failed to mint NFT', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleTransfer = async () => {
    if (!transferFrom || !transferTo || !transferTokenId) {
      showToast('Please fill all fields', 'error');
      return;
    }

    try {
      setLoading(true);
      const tx = await contract.safeTransferFrom(transferFrom, transferTo, transferTokenId);
      showToast('Transfer transaction sent...', 'info');
      await tx.wait();
      showToast('NFT transferred successfully!', 'success');
      setTransferFrom('');
      setTransferTo('');
      setTransferTokenId('');
    } catch (error) {
      console.error('Transfer error:', error);
      if (error.code === 4001) {
        showToast('User rejected transaction', 'error');
      } else {
        showToast('Failed to transfer NFT', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!approveTo || !approveTokenId) {
      showToast('Please fill all fields', 'error');
      return;
    }

    try {
      setLoading(true);
      const tx = await contract.approve(approveTo, approveTokenId);
      showToast('Approve transaction sent...', 'info');
      await tx.wait();
      showToast('Approval set successfully!', 'success');
      setApproveTo('');
      setApproveTokenId('');
    } catch (error) {
      console.error('Approve error:', error);
      if (error.code === 4001) {
        showToast('User rejected transaction', 'error');
      } else {
        showToast('Failed to set approval', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSetApprovalForAll = async () => {
    if (!setApprovalForAllOperator) {
      showToast('Please enter operator address', 'error');
      return;
    }

    try {
      setLoading(true);
      const tx = await contract.setApprovalForAll(setApprovalForAllOperator, setApprovalForAllApproved);
      showToast('SetApprovalForAll transaction sent...', 'info');
      await tx.wait();
      showToast(`Approval for all ${setApprovalForAllApproved ? 'granted' : 'revoked'}!`, 'success');
      setSetApprovalForAllOperator('');
      setSetApprovalForAllApproved(false);
    } catch (error) {
      console.error('SetApprovalForAll error:', error);
      if (error.code === 4001) {
        showToast('User rejected transaction', 'error');
      } else {
        showToast('Failed to set approval for all', 'error');
      }
    } finally {
      setLoading(false);
    }
  };

  const fillCurrentAccount = (field) => {
    if (!account) {
      showToast('Please connect wallet first', 'error');
      return;
    }
    
    switch (field) {
      case 'mintTo':
        setMintTo(account);
        break;
      case 'transferFrom':
        setTransferFrom(account);
        break;
      case 'approveTo':
        setApproveTo(account);
        break;
      case 'setApprovalForAllOperator':
        setSetApprovalForAllOperator(account);
        break;
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-4xl font-cyber font-bold mb-2 bg-gradient-to-r from-cyber-purple to-cyber-pink bg-clip-text text-transparent">
          NFT MANAGEMENT
        </h2>
        <p className="text-cyber-gray">Mint, transfer, and manage NFT approvals</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Mint Section */}
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-blue/30">
          <h3 className="text-2xl font-cyber text-cyber-blue mb-6">MINT NFT</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-cyber-gray mb-2">Recipient Address</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={mintTo}
                  onChange={(e) => setMintTo(e.target.value)}
                  placeholder="0x..."
                  className="flex-1 bg-cyber-dark border border-cyber-blue/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-blue"
                />
                <button
                  onClick={() => fillCurrentAccount('mintTo')}
                  className="px-4 bg-cyber-blue/20 hover:bg-cyber-blue/30 text-cyber-blue rounded-lg text-sm"
                >
                  USE MY ADDRESS
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm text-cyber-gray mb-2">Token URI</label>
              <input
                type="text"
                value={mintURI}
                onChange={(e) => setMintURI(e.target.value)}
                placeholder="ipfs://... or https://..."
                className="w-full bg-cyber-dark border border-cyber-blue/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-blue"
              />
            </div>
            <button
              onClick={handleMint}
              disabled={loading || !account}
              className="w-full py-3 bg-gradient-to-r from-cyber-blue to-cyber-purple hover:from-cyber-purple hover:to-cyber-blue text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  MINTING...
                </div>
              ) : (
                'MINT NFT'
              )}
            </button>
          </div>
        </div>

        {/* Transfer Section */}
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-purple/30">
          <h3 className="text-2xl font-cyber text-cyber-purple mb-6">TRANSFER NFT</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-cyber-gray mb-2">From Address</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={transferFrom}
                  onChange={(e) => setTransferFrom(e.target.value)}
                  placeholder="0x..."
                  className="flex-1 bg-cyber-dark border border-cyber-purple/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-purple"
                />
                <button
                  onClick={() => fillCurrentAccount('transferFrom')}
                  className="px-4 bg-cyber-purple/20 hover:bg-cyber-purple/30 text-cyber-purple rounded-lg text-sm"
                >
                  USE MY ADDRESS
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm text-cyber-gray mb-2">To Address</label>
              <input
                type="text"
                value={transferTo}
                onChange={(e) => setTransferTo(e.target.value)}
                placeholder="0x..."
                className="w-full bg-cyber-dark border border-cyber-purple/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-purple"
              />
            </div>
            <div>
              <label className="block text-sm text-cyber-gray mb-2">Token ID</label>
              <input
                type="text"
                value={transferTokenId}
                onChange={(e) => setTransferTokenId(e.target.value)}
                placeholder="123"
                className="w-full bg-cyber-dark border border-cyber-purple/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-purple"
              />
            </div>
            <button
              onClick={handleTransfer}
              disabled={loading || !account}
              className="w-full py-3 bg-gradient-to-r from-cyber-purple to-cyber-pink hover:from-cyber-pink hover:to-cyber-purple text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  TRANSFERRING...
                </div>
              ) : (
                'TRANSFER NFT'
              )}
            </button>
          </div>
        </div>

        {/* Approve Section */}
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-pink/30">
          <h3 className="text-2xl font-cyber text-cyber-pink mb-6">APPROVE NFT</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-cyber-gray mb-2">Approved Address</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={approveTo}
                  onChange={(e) => setApproveTo(e.target.value)}
                  placeholder="0x..."
                  className="flex-1 bg-cyber-dark border border-cyber-pink/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-pink"
                />
                <button
                  onClick={() => fillCurrentAccount('approveTo')}
                  className="px-4 bg-cyber-pink/20 hover:bg-cyber-pink/30 text-cyber-pink rounded-lg text-sm"
                >
                  USE MY ADDRESS
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm text-cyber-gray mb-2">Token ID</label>
              <input
                type="text"
                value={approveTokenId}
                onChange={(e) => setApproveTokenId(e.target.value)}
                placeholder="123"
                className="w-full bg-cyber-dark border border-cyber-pink/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-pink"
              />
            </div>
            <button
              onClick={handleApprove}
              disabled={loading || !account}
              className="w-full py-3 bg-gradient-to-r from-cyber-pink to-cyber-blue hover:from-cyber-blue hover:to-cyber-pink text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  APPROVING...
                </div>
              ) : (
                'APPROVE NFT'
              )}
            </button>
          </div>
        </div>

        {/* Set Approval For All */}
        <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-green/30">
          <h3 className="text-2xl font-cyber text-cyber-green mb-6">SET APPROVAL FOR ALL</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm text-cyber-gray mb-2">Operator Address</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={setApprovalForAllOperator}
                  onChange={(e) => setSetApprovalForAllOperator(e.target.value)}
                  placeholder="0x..."
                  className="flex-1 bg-cyber-dark border border-cyber-green/30 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-cyber-green"
                />
                <button
                  onClick={() => fillCurrentAccount('setApprovalForAllOperator')}
                  className="px-4 bg-cyber-green/20 hover:bg-cyber-green/30 text-cyber-green rounded-lg text-sm"
                >
                  USE MY ADDRESS
                </button>
              </div>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="approved"
                checked={setApprovalForAllApproved}
                onChange={(e) => setSetApprovalForAllApproved(e.target.checked)}
                className="w-5 h-5 mr-3 bg-cyber-dark border-cyber-green rounded"
              />
              <label htmlFor="approved" className="text-sm text-cyber-gray">
                Grant approval for all NFTs
              </label>
            </div>
            <button
              onClick={handleSetApprovalForAll}
              disabled={loading || !account}
              className="w-full py-3 bg-gradient-to-r from-cyber-green to-cyber-blue hover:from-cyber-blue hover:to-cyber-green text-white rounded-lg font-cyber font-bold transition-all duration-300 disabled:opacity-50"
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                  UPDATING...
                </div>
              ) : (
                `SET APPROVAL FOR ALL (${setApprovalForAllApproved ? 'GRANT' : 'REVOKE'})`
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Info Panel */}
      <div className="bg-cyber-gray/20 rounded-xl p-6 border border-cyber-blue/20">
        <h3 className="text-xl font-cyber text-cyber-blue mb-4">INSTRUCTIONS</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
          <div className="p-4 bg-cyber-dark/50 rounded-lg">
            <div className="text-cyber-green font-cyber mb-2">MINT</div>
            <p className="text-cyber-gray">Create a new NFT. Requires owner privileges.</p>
          </div>
          <div className="p-4 bg-cyber-dark/50 rounded-lg">
            <div className="text-cyber-purple font-cyber mb-2">TRANSFER</div>
            <p className="text-cyber-gray">Transfer NFT between addresses. You must own the NFT or be approved.</p>
          </div>
          <div className="p-4 bg-cyber-dark/50 rounded-lg">
            <div className="text-cyber-pink font-cyber mb-2">APPROVE</div>
            <p className="text-cyber-gray">Grant permission for another address to manage your NFT.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NFTManagement;