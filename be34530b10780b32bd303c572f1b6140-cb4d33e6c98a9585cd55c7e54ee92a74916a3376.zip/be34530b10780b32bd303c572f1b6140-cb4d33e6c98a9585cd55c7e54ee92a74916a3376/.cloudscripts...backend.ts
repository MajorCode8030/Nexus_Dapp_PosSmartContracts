import { ethers } from "ethers";

const NFT_ABI = [
  "function mint(address to, string calldata uri) external returns (uint256)",
  "function totalSupply() external view returns (uint256)",
  "function tokenURI(uint256 tokenId) external view returns (string)",
  "event NFTMinted(address indexed to, uint256 indexed tokenId, string tokenURI)"
];

const STAKING_ABI = [
  "function stake(uint256 tokenId) external",
  "function unstake(uint256 tokenId) external",
  "function claimRewards() external",
  "function getStakeInfo(uint256 tokenId) external view returns (address owner, uint256 stakedAt, uint256 currentReward)",
  "function getStakedTokens(address user) external view returns (uint256[])",
  "function pendingRewards(address) external view returns (uint256)"
];

const DAO_ABI = [
  "function propose(address[] memory targets, uint256[] memory values, bytes[] memory calldatas, string memory description) external returns (uint256)",
  "function castVote(uint256 proposalId, uint8 support) external returns (uint256)",
  "function state(uint256 proposalId) external view returns (uint8)",
  "function proposalVotes(uint256 proposalId) external view returns (uint256 againstVotes, uint256 forVotes, uint256 abstainVotes)"
];

const ORACLE_ABI = [
  "function getLatestPrice() external view returns (int256 price, uint256 updatedAt)",
  "function getDecimals() external view returns (uint8)"
];

export const CONTRACT_ADDRESSES = {
  NFT: "",
  STAKING: "",
  DAO: "",
  ORACLE: ""
};

export function getProvider(rpcUrl: string = "http://localhost:8545") {
  return new ethers.JsonRpcProvider(rpcUrl);
}

export function getNFTContract(signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(CONTRACT_ADDRESSES.NFT, NFT_ABI, signerOrProvider);
}

export function getStakingContract(signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(CONTRACT_ADDRESSES.STAKING, STAKING_ABI, signerOrProvider);
}

export function getDAOContract(signerOrProvider: ethers.Signer | ethers.Provider) {
  return new ethers.Contract(CONTRACT_ADDRESSES.DAO, DAO_ABI, signerOrProvider);
}

export function getOracleContract(provider: ethers.Provider) {
  return new ethers.Contract(CONTRACT_ADDRESSES.ORACLE, ORACLE_ABI, provider);
}

export async function mintNFT(signer: ethers.Signer, to: string, uri: string) {
  const nft = getNFTContract(signer);
  const tx = await nft.mint(to, uri);
  return tx.wait();
}

export async function stakeNFT(signer: ethers.Signer, tokenId: number) {
  const staking = getStakingContract(signer);
  const tx = await staking.stake(tokenId);
  return tx.wait();
}

export async function unstakeNFT(signer: ethers.Signer, tokenId: number) {
  const staking = getStakingContract(signer);
  const tx = await staking.unstake(tokenId);
  return tx.wait();
}

export async function claimRewards(signer: ethers.Signer) {
  const staking = getStakingContract(signer);
  const tx = await staking.claimRewards();
  return tx.wait();
}

export async function getLatestPrice(provider: ethers.Provider) {
  const oracle = getOracleContract(provider);
  const [price, updatedAt] = await oracle.getLatestPrice();
  const decimals = await oracle.getDecimals();
  return { price, updatedAt, decimals };
}

export async function createProposal(
  signer: ethers.Signer,
  targets: string[],
  values: bigint[],
  calldatas: string[],
  description: string
) {
  const dao = getDAOContract(signer);
  const tx = await dao.propose(targets, values, calldatas, description);
  return tx.wait();
}

export async function castVote(signer: ethers.Signer, proposalId: bigint, support: 0 | 1 | 2) {
  const dao = getDAOContract(signer);
  const tx = await dao.castVote(proposalId, support);
  return tx.wait();
}
